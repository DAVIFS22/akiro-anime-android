package com.akiro.anime.ui.screens.player

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.akiro.anime.data.repository.TorrentManager

@Composable
fun PlayerScreen(streamUrl: String?, title: String) {
    val context = LocalContext.current
    val torrentManager = remember { TorrentManager(context) }

    var playableUrl by remember(streamUrl) {
        mutableStateOf(streamUrl?.takeUnless { it.startsWith("magnet:", ignoreCase = true) })
    }
    var loading by remember(streamUrl) { mutableStateOf(streamUrl?.startsWith("magnet:", true) == true) }
    var error by remember(streamUrl) { mutableStateOf<String?>(null) }

    LaunchedEffect(streamUrl) {
        if (!streamUrl.orEmpty().startsWith("magnet:", true)) {
            loading = false
            return@LaunchedEffect
        }
        loading = true
        error = null
        torrentManager.streamFromMagnet(
            magnetLink = streamUrl,
            onReady = { playableUrl = it; loading = false },
            onError = { error = it.message ?: "Não foi possível iniciar a fonte."; loading = false }
        )
    }

    DisposableEffect(Unit) {
        onDispose { torrentManager.release() }
    }

    val url = playableUrl
    if (url.isNullOrBlank()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(28.dp)
            ) {
                if (loading) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(16.dp))
                    Text("Preparando reprodução", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Conectando aos pares e preparando os primeiros dados…",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        error ?: "Nenhuma fonte disponível.",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }
        return
    }

    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(player) {
        onDispose { player.release() }
    }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                keepScreenOn = true
                setBackgroundColor(android.graphics.Color.BLACK)
            }
        }
    )
}
