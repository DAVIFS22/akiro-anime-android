package com.akiro.anime

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.akiro.anime.ui.screens.detail.AnimeDetailScreen
import com.akiro.anime.ui.screens.favorites.FavoritesScreen
import com.akiro.anime.ui.screens.home.HomeScreen
import com.akiro.anime.ui.screens.player.PlayerScreen
import com.akiro.anime.ui.screens.search.SearchScreen
import com.akiro.anime.ui.theme.AkiroAnimeTheme
import java.net.URLDecoder
import java.net.URLEncoder

private sealed class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    data object Home : Tab("home", "Início", Icons.Default.Home)
    data object Search : Tab("search", "Buscar", Icons.Default.Search)
    data object Favorites : Tab("favorites", "Favoritos", Icons.Default.Favorite)
}

private val tabs = listOf(Tab.Home, Tab.Search, Tab.Favorites)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AkiroAnimeTheme {
                Surface(Modifier.fillMaxSize()) { AkiroApp() }
            }
        }
    }
}

@Composable
private fun AkiroApp() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val showBottomBar = tabs.any { it.route == route }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = { if (showBottomBar) BottomBar(nav) }
    ) { padding ->
        NavHost(nav, "home", modifier = Modifier) {
            composable("home") {
                HomeScreen(
                    onAnimeClick = { nav.navigate("detail/$it") },
                    onSearchClick = { nav.navigate("search") }
                )
            }
            composable("search") {
                SearchScreen(onAnimeClick = { nav.navigate("detail/$it") })
            }
            composable("favorites") {
                FavoritesScreen(onAnimeClick = { nav.navigate("detail/$it") })
            }
            composable(
                "detail/{animeId}",
                arguments = listOf(navArgument("animeId") { type = NavType.StringType })
            ) { entry ->
                AnimeDetailScreen(
                    animeId = entry.arguments?.getString("animeId").orEmpty(),
                    onEpisodeClick = { episode, stream ->
                        val title = URLEncoder.encode(episode.title, "UTF-8")
                        val url = URLEncoder.encode(stream.orEmpty(), "UTF-8")
                        nav.navigate("player/$title/$url")
                    }
                )
            }
            composable(
                "player/{title}/{streamUrl}",
                arguments = listOf(
                    navArgument("title") { type = NavType.StringType },
                    navArgument("streamUrl") { type = NavType.StringType }
                )
            ) { entry ->
                PlayerScreen(
                    title = URLDecoder.decode(entry.arguments?.getString("title").orEmpty(), "UTF-8"),
                    streamUrl = URLDecoder.decode(entry.arguments?.getString("streamUrl").orEmpty(), "UTF-8").ifBlank { null }
                )
            }
        }
    }
}

@Composable
private fun BottomBar(nav: NavHostController) {
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route
    NavigationBar {
        tabs.forEach { tab ->
            NavigationBarItem(
                selected = current == tab.route,
                onClick = {
                    nav.navigate(tab.route) {
                        popUpTo("home") { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(tab.icon, null) },
                label = { Text(tab.label) }
            )
        }
    }
}
