package com.akiro.anime.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AkiroColors = darkColorScheme(
    primary = Color(0xFFE50914),
    onPrimary = Color.White,
    secondary = Color(0xFFB8B8C2),
    background = Color(0xFF090A0D),
    onBackground = Color(0xFFF5F5F7),
    surface = Color(0xFF111318),
    onSurface = Color(0xFFF5F5F7),
    surfaceVariant = Color(0xFF1A1D23),
    onSurfaceVariant = Color(0xFFB7BBC5),
)

@Composable
fun AkiroAnimeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AkiroColors,
        typography = Typography(),
        content = content
    )
}
