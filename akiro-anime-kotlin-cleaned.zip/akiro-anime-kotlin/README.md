# Akiro Anime — Android Kotlin

Interface reorganizada para uma experiência simples de catálogo + player.

## Arquitetura do player

- HTTP/HTTPS: Media3/ExoPlayer reproduz diretamente.
- `magnet:`: `TorrentManager` usa libtorrent4j e expõe o arquivo por HTTP local com suporte a Range.
- O servidor local fica preso a `127.0.0.1` e não é exposto na rede.

## Importante sobre fontes

O projeto não inclui um catálogo ou integração automática com serviços de terceiros que agreguem links de conteúdo protegido por direitos autorais. O motor de magnet pode ser usado para torrents que você tenha direito de reproduzir, incluindo conteúdo próprio, autorizado ou de domínio público.

## UX

- Home com seções horizontais e uma única lista vertical.
- Cards menores e consistentes.
- Navegação inferior somente nas telas principais.
- Player separado do catálogo.
- Estados de carregamento/erro mais limpos.
