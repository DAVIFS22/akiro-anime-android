package com.akiro.anime.data.storage

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "akiro_prefs")

data class FavoriteItem(
    val animeId: String,
    val title: String,
    val poster: String,
    val addedAt: Long,
)

data class HistoryItem(
    val animeId: String,
    val title: String,
    val poster: String,
    val season: Int,
    val episode: Int,
    val positionSeconds: Int,
    val durationSeconds: Int,
    val updatedAt: Long,
)

data class AppSettings(
    val autoPlayNext: Boolean = true,
    val subtitlesEnabled: Boolean = true,
    val defaultQuality: String = "1080p",
)

// Mirrors src/storage/localStorage.ts, adapted to DataStore (async) since
// Android has no synchronous browser-style storage.
class StorageManager(private val context: Context) {
    private val gson = Gson()

    private object Keys {
        val FAVORITES = stringPreferencesKey("favorites")
        val HISTORY = stringPreferencesKey("history")
        val SETTINGS = stringPreferencesKey("settings")
    }

    val favoritesFlow: Flow<List<FavoriteItem>> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.FAVORITES] ?: return@map emptyList()
        runCatching {
            val type = object : TypeToken<List<FavoriteItem>>() {}.type
            gson.fromJson<List<FavoriteItem>>(raw, type)
        }.getOrDefault(emptyList())
    }

    val historyFlow: Flow<List<HistoryItem>> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.HISTORY] ?: return@map emptyList()
        runCatching {
            val type = object : TypeToken<List<HistoryItem>>() {}.type
            gson.fromJson<List<HistoryItem>>(raw, type)
        }.getOrDefault(emptyList())
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.SETTINGS] ?: return@map AppSettings()
        runCatching { gson.fromJson(raw, AppSettings::class.java) }.getOrDefault(AppSettings())
    }

    suspend fun toggleFavorite(item: FavoriteItem): Boolean {
        var isFavorite = false
        context.dataStore.edit { prefs ->
            val type = object : TypeToken<List<FavoriteItem>>() {}.type
            val current: List<FavoriteItem> = prefs[Keys.FAVORITES]
                ?.let { runCatching { gson.fromJson<List<FavoriteItem>>(it, type) }.getOrNull() }
                ?: emptyList()

            val exists = current.any { it.animeId == item.animeId }
            val updated = if (exists) {
                current.filterNot { it.animeId == item.animeId }
            } else {
                isFavorite = true
                listOf(item) + current
            }
            prefs[Keys.FAVORITES] = gson.toJson(updated)
        }
        return isFavorite
    }

    suspend fun saveWatchProgress(item: HistoryItem) {
        context.dataStore.edit { prefs ->
            val type = object : TypeToken<List<HistoryItem>>() {}.type
            val current: List<HistoryItem> = prefs[Keys.HISTORY]
                ?.let { runCatching { gson.fromJson<List<HistoryItem>>(it, type) }.getOrNull() }
                ?: emptyList()

            val filtered = current.filterNot {
                it.animeId == item.animeId && it.season == item.season && it.episode == item.episode
            }
            val updated = (listOf(item) + filtered).take(50)
            prefs[Keys.HISTORY] = gson.toJson(updated)
        }
    }

    suspend fun removeHistoryItem(animeId: String, season: Int, episode: Int) {
        context.dataStore.edit { prefs ->
            val type = object : TypeToken<List<HistoryItem>>() {}.type
            val current: List<HistoryItem> = prefs[Keys.HISTORY]
                ?.let { runCatching { gson.fromJson<List<HistoryItem>>(it, type) }.getOrNull() }
                ?: emptyList()
            val updated = current.filterNot {
                it.animeId == animeId && it.season == season && it.episode == episode
            }
            prefs[Keys.HISTORY] = gson.toJson(updated)
        }
    }

    suspend fun clearHistory() {
        context.dataStore.edit { prefs -> prefs[Keys.HISTORY] = gson.toJson(emptyList<HistoryItem>()) }
    }

    suspend fun saveSettings(settings: AppSettings) {
        context.dataStore.edit { prefs -> prefs[Keys.SETTINGS] = gson.toJson(settings) }
    }
}
