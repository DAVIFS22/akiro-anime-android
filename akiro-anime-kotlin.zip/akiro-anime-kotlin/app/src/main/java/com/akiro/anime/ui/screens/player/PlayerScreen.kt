package com.akiro.anime.ui.screens.player

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/**
 * Plays a direct HTTP(S) video URL (mp4/HLS/DASH) via Media3/ExoPlayer.
 *
 * IMPORTANT: this does NOT resolve magnet: links. The addons this app uses
 * (Torrentio, Brazuca) return magnet links, which need a torrent-to-HTTP
 * resolver running somewhere before they can reach this player. See the
 * README for details — this remains the single biggest unsolved piece of
 * the project.
 */
@Composable
fun PlayerScreen(streamUrl: String?, title: String) {
    if (streamUrl == null || streamUrl.startsWith("magnet:")) {
        UnresolvedStreamMessage(title)
        return
    }

    val context = LocalContext.current
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(streamUrl))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = {
            PlayerView(it).apply {
                player = exoPlayer
                setBackgroundColor(android.graphics.Color.BLACK)
            }
        }
    )
}

@Composable
private fun UnresolvedStreamMessage(title: String) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Não foi possível reproduzir \"$title\"", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Esse episódio só tem fontes magnet: (torrent) disponíveis, e o app " +
                "ainda não tem um serviço que converte isso em um stream direto. " +
                "Veja o README do projeto para mais detalhes sobre esse ponto.",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center
        )
    }
}
