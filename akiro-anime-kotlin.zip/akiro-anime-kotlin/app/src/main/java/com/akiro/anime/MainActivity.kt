package com.akiro.anime

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.akiro.anime.ui.screens.detail.AnimeDetailScreen
import com.akiro.anime.ui.screens.home.HomeScreen
import com.akiro.anime.ui.theme.AkiroAnimeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AkiroAnimeTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AkiroNavHost()
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
fun AkiroNavHost() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(onAnimeClick = { animeId ->
                navController.navigate("detail/$animeId")
            })
        }
        composable(
            "detail/{animeId}",
            arguments = listOf(navArgument("animeId") { type = NavType.StringType })
        ) { backStackEntry ->
            val animeId = backStackEntry.arguments?.getString("animeId") ?: ""
            AnimeDetailScreen(animeId = animeId)
        }
    }
}
