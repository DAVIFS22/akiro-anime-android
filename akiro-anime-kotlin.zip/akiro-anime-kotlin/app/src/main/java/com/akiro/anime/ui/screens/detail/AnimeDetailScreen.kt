package com.akiro.anime.ui.screens.detail

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// TODO: replace with the full detail screen (seasons/episodes list, cast,
// stream source selection) migrated from views/AnimeDetailView.tsx.
@Composable
fun AnimeDetailScreen(animeId: String) {
    Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
        Text(
            text = "Detalhes do anime #$animeId (em construção)",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}
