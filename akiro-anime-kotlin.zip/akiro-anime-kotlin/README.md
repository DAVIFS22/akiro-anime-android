# Akiro Anime — Android Nativo (Kotlin + Jetpack Compose)

Reescrita 100% nativa do projeto web Akiro Anime. Sem WebView — telas em
Jetpack Compose, rede via Retrofit, players nativos via Media3.

## Status atual (esqueleto funcional)

O que já existe e deve compilar:
- Estrutura Gradle completa (`build.gradle.kts`, módulo `app`)
- Modelos de dados (`data/model/Anime.kt`) migrados de `types/anime.ts`
- Camada de rede TMDB (`network/TmdbApi.kt`, `RetrofitClient.kt`) — chama
  a API do TMDB **diretamente** (sem proxy CORS, diferente da versão web)
- `AnimeRepository` mapeando respostas do TMDB pro modelo do app
- Tela Home (`ui/screens/home/`) mostrando "Em alta" e "Populares" com pôsteres
- Navegação básica Home → Detalhe (tela de detalhe ainda é placeholder)
- Workflow do GitHub Actions pra compilar o APK automaticamente

## O que falta (próximas etapas)

1. **Tela de detalhes completa** — temporadas, episódios, elenco, seleção de fonte de stream (migrar de `views/AnimeDetailView.tsx`)
2. **Player de vídeo** com Media3/ExoPlayer
3. **O maior desafio técnico do projeto**: resolver links `magnet:` dos addons (Torrentio/Brazuca) para algo reproduzível — não existe solução trivial nativa; provavelmente vai precisar de um pequeno serviço hospedado que converte torrent → stream HTTP
4. **Armazenamento local** (favoritos, histórico, configurações) via DataStore, substituindo o `localStorage`
5. **Autenticação e sincronização Firebase** (ver abaixo, precisa de configuração)
6. **Tela de busca, catálogo com filtros, notificações**

## Antes de rodar o build

### 1. Chave da API do TMDB
Crie um secret no GitHub chamado `TMDB_API_KEY` (Settings → Secrets and variables → Actions) com sua chave do TMDB.
Sem isso as chamadas ao catálogo retornam vazio.

### 2. Firebase — atenção, precisa reconfigurar
O arquivo `firebase-applet-config.json` do projeto original é uma
configuração **web** do Firebase. Ela **não funciona** no Android nativo.
Para reativar login/reviews/sincronização:
1. Abra o [Firebase Console](https://console.firebase.google.com/), projeto `gen-lang-client-0742851387`
2. Adicione um app Android novo com o pacote `com.akiro.anime`
3. Baixe o `google-services.json` gerado e coloque em `app/google-services.json`
4. Descomente as duas linhas `com.google.gms.google-services` em `build.gradle.kts` e `app/build.gradle.kts`

Até isso ser feito, o app compila e funciona (catálogo, navegação) mas sem login/sincronização.

### 3. Ícone do app
Coloquei um ícone provisório (triângulo de play). Troque
`app/src/main/res/drawable/ic_launcher_foreground.xml` pela arte final quando tiver.

## Como gerar o APK

O repositório já tem um workflow (`.github/workflows/build-apk.yml`) configurado.
Depois de subir este código pro GitHub (com o secret `TMDB_API_KEY` configurado):

1. Vá na aba **Actions** do repositório
2. Rode o workflow **Build Akiro Anime APK** manualmente (ou dê um push na branch `main`)
3. Quando terminar, baixe o artefato `akiro-anime-debug-apk` — é o `.apk` pronto pra instalar

**Importante:** este projeto foi escrito sem conseguir compilar localmente (o
ambiente que gerou este código não tem acesso ao repositório Maven do
Google). É bem possível que o primeiro build no GitHub Actions aponte algum
erro de compilação — se acontecer, me manda o log de erro que eu corrijo.
