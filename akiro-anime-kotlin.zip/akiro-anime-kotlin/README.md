# Akiro Anime — Android Nativo (Kotlin + Jetpack Compose)

Reescrita 100% nativa do projeto web Akiro Anime. Sem WebView — telas em
Jetpack Compose, rede via Retrofit, players nativos via Media3.

## Status atual

O que já existe e deve compilar:
- Estrutura Gradle completa (`build.gradle.kts`, módulo `app`)
- Modelos de dados (`data/model/Anime.kt`) migrados de `types/anime.ts`
- Camada de rede TMDB (`network/TmdbApi.kt`, `RetrofitClient.kt`) — chama
  a API do TMDB **diretamente** (sem proxy CORS, diferente da versão web)
- `AnimeRepository` mapeando respostas do TMDB pro modelo do app
- **Home** — "Em alta" e "Populares" com pôsteres reais do TMDB
- **Busca** — campo de texto com debounce, resultados em grade
- **Detalhes do anime** — sinopse, gêneros, seletor de temporada, lista de episódios, botão de favoritar
- **Favoritos / Continuar assistindo** — duas abas, salvos localmente via DataStore
- **Player** — Media3/ExoPlayer, toca URLs diretas (mp4/HLS); mostra aviso claro quando só existe fonte `magnet:`
- Navegação por abas inferiores (Início / Buscar / Favoritos) + telas de detalhe e player empilhadas por cima
- Armazenamento local (`data/storage/StorageService.kt`) via DataStore, substituindo `localStorage`
- Workflow do GitHub Actions pra compilar o APK automaticamente

## O que falta (o maior ponto em aberto)

**Resolver links `magnet:` dos addons (Torrentio/Brazuca) para algo reproduzível.**
Não existe solução trivial nativa — provavelmente vai precisar de um pequeno
serviço hospedado que converte torrent → stream HTTP. Sem isso, o player
mostra a mensagem de "não foi possível reproduzir" pra qualquer episódio
cuja única fonte seja magnet.

Outros pontos menores:
- A tela de detalhes ainda não busca as fontes de stream dos addons (Torrentio/Brazuca) — está preparada para receber uma URL, mas essa busca ainda não foi implementada
- Autenticação e sincronização Firebase (ver seção abaixo)
- Notificações de novos episódios

## Antes de rodar o build

### 1. Chave da API do TMDB
Crie um secret no GitHub chamado `TMDB_API_KEY` (Settings → Secrets and variables → Actions) com sua chave do TMDB.
Sem isso as chamadas ao catálogo retornam vazio.

### 2. Firebase — atenção, precisa reconfigurar
O arquivo `firebase-applet-config.json` do projeto original é uma
configuração **web** do Firebase. Ela **não funciona** no Android nativo.
Para reativar login/reviews/sincronização:
1. Abra o [Firebase Console](https://console.firebase.google.com/), projeto `gen-lang-client-0742851387`
2. Adicione um app Android novo com o pacote `com.akiro.anime`
3. Baixe o `google-services.json` gerado e coloque em `app/google-services.json`
4. Descomente as duas linhas `com.google.gms.google-services` em `build.gradle.kts` e `app/build.gradle.kts`

Até isso ser feito, o app compila e funciona (catálogo, navegação) mas sem login/sincronização.

### 3. Ícone do app
Coloquei um ícone provisório (triângulo de play). Troque
`app/src/main/res/drawable/ic_launcher_foreground.xml` pela arte final quando tiver.

## Como gerar o APK

O repositório já tem um workflow (`.github/workflows/build-apk.yml`) configurado.
Depois de subir este código pro GitHub (com o secret `TMDB_API_KEY` configurado):

1. Vá na aba **Actions** do repositório
2. Rode o workflow **Build Akiro Anime APK** manualmente (ou dê um push na branch `main`)
3. Quando terminar, baixe o artefato `akiro-anime-debug-apk` — é o `.apk` pronto pra instalar

**Importante:** este projeto foi escrito sem conseguir compilar localmente (o
ambiente que gerou este código não tem acesso ao repositório Maven do
Google). É bem possível que o primeiro build no GitHub Actions aponte algum
erro de compilação — se acontecer, me manda o log de erro que eu corrijo.
